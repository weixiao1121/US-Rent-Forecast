# Team-96
 Team 96's group project GitHub repository for MGT 6203 (Canvas) Spring of 2024 semester.

## Project
Prediction of Monthly Rent in United States Based on Property Features

## Datasets
Datasets have been uploaded to Dropbox for your reference. (https://www.dropbox.com/scl/fo/cb187tf0l039pi09rcxp4/AEOEH07BJAl8Y8guOWPio4A?rlkey=7sbv4fnx0vxob5u06ntjkgf5k&st=uz0ob33n&dl=0)  
+ full dataset: housing_data.csv  
+ cleaned training dataset: training_data.csv  
+ cleaned testing dataset: testing_data.csv  

## Code
+ EDA
  + MGT_Progress_Report.ipynb (note that Preeti had technical difficulties with being added to our team Github. This code was written by her and committed on to Github on her behalf)
  + Progress Report_LinAssump_EDA.R
+ Modeling
  + Linear Regression Models
    + initial_linear_regression.R
    + LogTransformation.R
  + Elastic Net
    + Elastic_Net.R
  + Linear SVM
    + linear_svm_model.R
  + Random Forest / XGBoost
    + MGT_Preeti_Team96.ipynb (again code contributed by Preeti, commited by teammate on her behalf)
  + Misc.
    + SupportRQ_1_2.R

## Libraries / Packages
+ R
  + readxl
  + grid
  + ggplot2
  + gridExtra
  + corrplot
  + dplyr
  + psych
  + GGally
  + car
  + e1071
  + caret
  + glmnet
  + dummies
+ Python
  + pandas 
  + numpy 
  + matplotlib
  + seaborn 
  + sklearn.model_selection
  + sklearn.ensemble 
  + sklearn.metrics
  + sklearn.preprocessing
  + xgboost


